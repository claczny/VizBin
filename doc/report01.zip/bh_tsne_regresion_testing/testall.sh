#!/bin/bash

cd $(dirname $0)

TFILE="times.txt"
DIR="points"

mkdir $DIR
date >> $TFILE
for version in `ls ./binaries/`
do
	for dataset in `ls ./data/`
	do
		echo "STATUS: running $version with dataset $dataset " >> $TFILE	
		for I in {1..4} 
		do

			sed "s/THREADS/$I/" <./data/$dataset/data.dat >./data.dat
	dat=`echo $dataset | rev | cut -d'/' -f2 | rev`
	ver=`echo $version | rev | cut -d'/' -f2 | rev`
	echo "Dataset: $dat" 
	echo "Version: $ver" 
			(time ./binaries/$version) 2>>$TFILE
			mv points.txt ./$DIR/points_"$dat"_"$ver"_$I
			echo "done ($ver on dataset $dat with $I threads)." >> $TFILE	
		done
		rm ./data.dat
	done
done
