#!/bin/bash

cd $(dirname $0)

TFILE="times.txt"
DIR="points"

mkdir $DIR
date >> $TFILE
for version in ./binaries/*
do
	for dataset in ./data/*
	do
		echo "STATUS: running $version with dataset $dataset " >> $TFILE	
		echo "Dataset: $dataset" 
		for I in {1..4} 
		do

			sed "s/THREADS/$I/" <$dataset/data.dat >./binaries/data.dat
			(time $version) 2>>$TFILE
			mv points.txt "./$DIR/points_$dataset\_$version\_$I"
			echo "done ($version on dataset $dataset with $I threads)." >> $TFILE	
		done
		rm ./binaries/data.dat
	done
done
